package com.example.petclinic.service;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.security.acl.Owner;

@Service
public class OwnerService{

    //private static final Logger log = LoggerFactory

            RestTemplate restTemplate;

        public OwnerService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public Owner saveOwner(RestTemplate restTemplate){

        URI uri = URI.create("http://localhost:9091/ownerapi/owner")

                Owner response = restTemplate.postForObject()
                        log.info(response.toString());
        return response;
    }


}




